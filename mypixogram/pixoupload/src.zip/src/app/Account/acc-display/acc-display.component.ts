import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-acc-display',
  templateUrl: './acc-display.component.html',
  styleUrls: ['./acc-display.component.css']
})
export class AccDisplayComponent implements OnInit {

  constructor() { 
    
  }

  ngOnInit() {
  }

}
