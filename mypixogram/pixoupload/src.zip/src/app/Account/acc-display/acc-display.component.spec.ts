import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AccDisplayComponent } from './acc-display.component';

describe('AccDisplayComponent', () => {
  let component: AccDisplayComponent;
  let fixture: ComponentFixture<AccDisplayComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AccDisplayComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AccDisplayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
