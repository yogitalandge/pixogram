import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-followings',
  templateUrl: './followings.component.html',
  styleUrls: ['./followings.component.css']
})
export class FollowingsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
